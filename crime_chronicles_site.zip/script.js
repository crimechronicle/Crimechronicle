async function loadPosts(){
  const res = await fetch('posts/posts.json');
  const posts = await res.json();
  const list = document.getElementById('post-list');
  posts.forEach(p=>{
    const card = document.createElement('article');
    card.className = 'post-card';
    card.innerHTML = `
      <div class="post-meta">${p.date} • ${p.type}</div>
      <h4><a class="post-link" href="posts/${p.id}.html">${p.title}</a></h4>
      <div class="post-excerpt">${p.excerpt}</div>
    `;
    list.appendChild(card);
  });
}

loadPosts();
